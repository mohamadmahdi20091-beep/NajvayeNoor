package ir.najvayenoor.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Emerald = Color(0xFF123B30)
private val Gold = Color(0xFFC6A15B)
private val Paper = Color(0xFFF3EBDD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NajvayeNoorApp() }
    }
}

@Composable
fun NajvayeNoorApp() {
    MaterialTheme(colorScheme = lightColorScheme(primary = Emerald, secondary = Gold, background = Paper)) {
        Scaffold(containerColor = Paper, bottomBar = {
            NavigationBar(containerColor = Emerald) {
                NavigationBarItem(selected = true, onClick = {}, icon = { Icon(Icons.Default.Home, null) }, label = { Text("خانه") })
                NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.MenuBook, null) }, label = { Text("کتابخانه") })
                NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.Headphones, null) }, label = { Text("صوت") })
                NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.Bookmark, null) }, label = { Text("نشانک‌ها") })
                NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("تنظیمات") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Text("نجوای نور", fontSize = 29.sp, fontWeight = FontWeight.Bold, color = Emerald)
                Text("کتابخانه دعا، قرآن و معارف اسلامی", color = Emerald.copy(alpha = .75f))
                Spacer(Modifier.height(16.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Text("امروز | تقویم شمسی و قمری", color = Gold)
                        Spacer(Modifier.height(8.dp))
                        Text("به نام خداوند بخشنده مهربان", color = Color.White, fontSize = 18.sp)
                        Text("دعای روز", color = Gold, modifier = Modifier.padding(top = 10.dp))
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text("کتابخانه معنوی", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Emerald)
                Spacer(Modifier.height(10.dp))
                val sections = listOf("قرآن کریم", "مفاتیح‌الجنان", "نهج‌البلاغه", "مناجات‌ها", "زیارات", "اعمال ماه‌ها و روزها")
                LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(sections) { title ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                            Box(Modifier.fillMaxWidth().height(112.dp).padding(12.dp), contentAlignment = Alignment.Center) {
                                Text(title, color = Emerald, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
